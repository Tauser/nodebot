#include "FaceService.h"
#include <Arduino.h>

void FaceService::init() {
    _renderer.init();
    
    _blinkAnim.attachModel(&_model);
    _saccadeAnim.attachModel(&_model);
    _emotionAnim.attachModel(&_model);

    _microTimer = 0;
    _currentEmotion = Emotion::NEUTRAL;
}

void FaceService::update(uint32_t deltaMs) {
    _microTimer += deltaMs;

    // Saccade Automático (Vida Involuntária)
    if (_microTimer > random(2000, 4000)) {
        _microTimer = 0;
        
        // Offset suave (-0.2 a 0.2)
        float tx = random(-20, 20) / 100.0f;
        float ty = random(-20, 20) / 100.0f;
        
        _saccadeAnim.setTarget(tx, ty);
        _engine.play(&_saccadeAnim);
    }

    _engine.update(deltaMs);
    _renderer.render(_model);
}

void FaceService::triggerBlink() {
    _engine.playOverlay(&_blinkAnim);
}

void FaceService::showEmotion(Emotion emotion) {
    if (_currentEmotion == emotion) return;
    _currentEmotion = emotion;

    float targetSize = 1.0f;
    switch (emotion) {
        case Emotion::HAPPY: targetSize = 1.2f; break;
        case Emotion::ANGRY: targetSize = 0.6f; break;
        case Emotion::SAD:   targetSize = 0.8f; break;
        case Emotion::SURPRISED: targetSize = 1.5f; break;
        default: break;
    }
    
    _emotionAnim.setTargetSize(targetSize);
    _engine.play(&_emotionAnim);
}