#pragma once
#include <stdint.h>
#include "model/EyeModel.h"
#include "render/FaceRenderer.h"
#include "animation/AnimationEngine.h"
#include "animation/BlinkAnimation.h"
#include "animation/SaccadeAnimation.h"
#include "animation/EmotionTransition.h"

enum class Emotion {
    NEUTRAL, HAPPY, SAD, ANGRY, SURPRISED, SLEEPING
};

class FaceService
{
public:
    void init();
    void update(uint32_t deltaMs);

    void showEmotion(Emotion emotion);
    void triggerBlink();

private:
    EyeModel _model;
    FaceRenderer _renderer;
    AnimationEngine _engine;

    // Instâncias estáticas das animações
    BlinkAnimation _blinkAnim;
    SaccadeAnimation _saccadeAnim;
    EmotionTransition _emotionAnim;

    uint32_t _microTimer;
    Emotion _currentEmotion;
};