#include "FaceRenderer.h"
#include "./core/config/hardware_config.h"

void FaceRenderer::init() {
    // Inicializa a tela com os pinos da tua Freenove S3
    _display.init(TFT_MOSI, TFT_SCLK, TFT_CS, TFT_DC, TFT_RST, TFT_BL, TFT_WIDTH, TFT_HEIGHT);
    _display.clearScreen(0x0000); 
}

void FaceRenderer::render(const EyeModel& eye) {
    _display.clearScreen(0x0000); // Limpa o frame (fundo preto)

    // --- LÊ OS DADOS DO TEU MOTOR DE ANIMAÇÃO ---
    // ATENÇÃO: Confirma se os nomes (scale, saccadeX, blinkAperture) 
    // são exatamente os que escreveste no teu EyeModel.h!
    float scale = eye.scale;           
    float offsetX = eye.saccadeX;      
    float offsetY = eye.saccadeY;      
    float blink = eye.blinkAperture;   

    // Calcula tamanho
    int baseWidth = 60 * scale;
    int baseHeight = 70 * scale;
    int actualHeight = baseHeight * blink; 

    if (actualHeight <= 2) return; // Olho fechado, não desenha

    // Calcula posição no ecrã (com o deslocamento do Saccade)
    int leftEyeCenterX = 80 + (offsetX * 50);
    int rightEyeCenterX = 240 + (offsetX * 50);
    int eyeCenterY = 120 + (offsetY * 50);

    // Renderiza via DisplayDriver
    _display.fillRect(leftEyeCenterX - (baseWidth / 2), eyeCenterY - (actualHeight / 2), baseWidth, actualHeight, 0xFFFF);
    _display.fillRect(rightEyeCenterX - (baseWidth / 2), eyeCenterY - (actualHeight / 2), baseWidth, actualHeight, 0xFFFF);
}