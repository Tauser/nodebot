#pragma once
#include "../model/EyeModel.h"
#include "drivers/DisplayDriver.h" // Ajusta o caminho se o teu driver estiver noutra pasta

class FaceRenderer {
public:
    void init();
    void render(const EyeModel& eye);

private:
    DisplayDriver _display;
};