#include "FaceRenderer.h"
#include "core/config/hardware_config.h"

void FaceRenderer::init() {
    _display.init(
        Hardware::Display::PIN_MOSI, Hardware::Display::PIN_SCLK,
        Hardware::Display::PIN_CS, Hardware::Display::PIN_DC,
        Hardware::Display::PIN_RST, Hardware::Display::PIN_BL,
        Hardware::Display::WIDTH, Hardware::Display::HEIGHT
    );
    _display.setBacklight(80);
    _display.clearScreen(0x0000); // Preto
}

void FaceRenderer::render(EyeModel& model) {
    EyeState s = model.get();

    // 🚀 OTIMIZAÇÃO: Só manda dados para o SPI se os valores mudaram!
    // (Poupe milhares de ciclos de CPU comparando as variáveis de estado)
    
    // Aqui usaremos funções avançadas do DisplayDriver para desenhar a geometria 
    // ou aplicar offsets em bitmaps baseados em s.pupilX, s.pupilY, etc.
    // Exemplo conceitual:
    
    // _display.drawEyeBase();
    // _display.drawPupil(s.pupilX, s.pupilY, s.pupilSize);
    // _display.drawLid(s.lidOpen);
}