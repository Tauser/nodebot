#pragma once
#include "../model/EyeModel.h"
#include "drivers/DisplayDriver.h"

class FaceRenderer {
private:
    DisplayDriver _display;
    EyeState _lastRenderedState; // Para otimizar e só desenhar se mudar

public:
    void init();
    void render(EyeModel& model);
};