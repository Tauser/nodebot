#include "DisplayDriver.h"
#include <Adafruit_GFX.h>
#include <Adafruit_ST7789.h> // De volta ao hardware real!
#include <SPI.h>

static Adafruit_ST7789* tft = nullptr;

bool DisplayDriver::init(int mosi, int sclk, int cs, int dc, int rst, int bl, uint16_t width, uint16_t height) {
    _width = width;
    _height = height;
    _blPin = bl;
    
    if (tft != nullptr) {
        delete tft;
    }
    
    // Inicializa a comunicação com o ST7789
    tft = new Adafruit_ST7789(cs, dc, mosi, sclk, rst);
    tft->init(width, height);
    
    // Orientação da tela
    tft->setRotation(1); 
    
    // Essencial para o ST7789: garante que as cores não fiquem invertidas (negativas)
    tft->invertDisplay(true);
    
    // Fundo preto puro do NodeBot
    tft->fillScreen(ST77XX_BLACK);
    
    // Configura o Backlight via PWM
    if (_blPin >= 0) {
        ledcSetup(1, 5000, 8); 
        ledcAttachPin(_blPin, 1);
        setBacklight(255); 
    }
    
    _isInitialized = true;
    return true;
}

void DisplayDriver::setBacklight(uint8_t brightness) {
    if (_blPin >= 0) ledcWrite(1, brightness); 
}

void DisplayDriver::clearScreen(uint16_t color) {
    if (tft) tft->fillScreen(color);
}

void DisplayDriver::fillRect(int x, int y, int w, int h, uint16_t color) {
    if (tft) tft->fillRect(x, y, w, h, color);
}

void DisplayDriver::fillCircle(int x, int y, int r, uint16_t color) {
    if (tft) tft->fillCircle(x, y, r, color);
}

void DisplayDriver::pushImage(uint16_t x, uint16_t y, uint16_t w, uint16_t h, const uint16_t* data) {
    if (tft) tft->drawRGBBitmap(x, y, data, w, h);
}